#ifndef ORDENACAO_H_INCLUDED
#define ORDENACAO_H_INCLUDED
#define TAMANHO_VETOR 10
#define ERRO    -1
#define SUCESSO  1
#define FALSE 0
#define TRUE  1

void bubbleShort(int vet[], int tam);

void selectionShort(int vet[], int tam);

void quickShort(int vet[], int inicio, int fim);

#endif // ORDENACAO_H_INCLUDED
